# dev-frame

> A Vue.js project

## Build Setup

``` bash
# install dependencies
# 建议先配置npm淘宝镜像 npm config set registry=http://registry.npm.taobao.org
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

## 参考资料
[ECMAScript 6入门](http://es6.ruanyifeng.com/)      
[eslint 安装](http://eslint.org/docs/user-guide/getting-started)      
[eslint sublime 配置](http://blog.csdn.net/lj745280746/article/details/49658249)      
[babel](http://babeljs.cn/)      

[vue文档](http://cn.vuejs.org/guide/installation.html)    MVVM框架  
[vue-router文档](http://router.vuejs.org/zh-cn/basic.html)    组件路由  
[vuex文档](http://vuex.vuejs.org/zh-cn/)  状态管理  
[vux文档](https://vuxjs.gitbooks.io/vux/content/) weChat UI组件  

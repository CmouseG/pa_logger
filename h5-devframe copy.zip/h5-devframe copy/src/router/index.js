import Vue from 'vue'
import VueRouter from 'vue-router'

import Home from '../views/Home'
import HelloWorld from '../views/HelloWorld'
import VuxDemo from '../views/VuxDemo'
import KeenuiDemo from '../views/KeenUiDemo'
import Logger from '../plugins/logger'

Vue.use(VueRouter)

export default new VueRouter({
    routes: [{
        path: '/',
        component: Home
    }, {
        path: '/hello-world',
        component: HelloWorld
    }, {
        path: '/vux-demo',
        component: VuxDemo
    }, {
        path: '/keenui-demo',
        component: KeenuiDemo
    }, {
        path: '/logger',
        component: Logger
    }, {
        path: '*',
        redirect: '/'
    }]
})

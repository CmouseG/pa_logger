import Vue from 'vue'
import Vuex from 'vuex'

import * as actions from './actions'
import * as getters from './getters'
import mutations from './mutations'
import logger from '../plugins/logger/install'
import aInput from './modules/vux-demo'

Vue.use(Vuex)

const state = {
    fromData: {}
}

export default new Vuex.Store({
    state,
    actions,
    mutations,
    getters,
    modules: {
        aInput: aInput
    },
    plugins: [logger()]
})

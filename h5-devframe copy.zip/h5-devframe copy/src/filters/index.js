import Vue from 'vue'

Vue.filter('formatDate', (timestamp) => {
    return new Date(timestamp).toLocaleTimeString()
})

Vue.filter('cellFlt', (keyword) => {
    console.log(33)
})

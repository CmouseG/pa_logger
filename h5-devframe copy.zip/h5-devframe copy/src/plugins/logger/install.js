/**
 * web前端日志核心
 * 提供日志记录、查询、订阅
 * 使用浏览器localStorage做持久化，默认占用1M空间，超过时清除较旧的日志记录
 *
 * @date 2015-11-18
 * @restructure 2015-10-14
 * @author 刘俊 (EX-LIUJUN012@pingan.com.cn)
 *
 */

export default function logger({transformer = state => state} = {}) {
    console.log(33)
    return store => {
        console.log(44)
        store.subscribe((mutation, state) => {
            console.log(55)
        })
    }
}

import Logger from './src/Logger'

export default Logger

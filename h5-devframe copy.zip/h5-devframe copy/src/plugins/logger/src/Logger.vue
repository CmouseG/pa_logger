    <template>
        <div id="H5log_content">
            <pa-search v-model="keyword"></pa-search>
            <div class="result_list">
                <ul class="levels">
                    <li class="color_all" :class="{active_all: active === 'tabAll'}" lev="6" sel="" style="" @click="active = 'tabAll'">ALL</li>
                    <li class="color_debug" :class="{active_debug: active === 'tabDebug'}" lev="0" style="" sel="" @click="active = 'tabDebug'">DEBUG</li>
                    <li class="color_info" :class="{active_info: active === 'tabInfo'}" lev="1" sel="1" @click="active = 'tabInfo'">INFO</li>
                    <li class="color_warn" :class="{active_warn: active === 'tabWarn'}" lev="2" style="" sel="" @click="active = 'tabWarn'">WARN</li>
                    <li class="color_error" :class="{active_error: active === 'tabError'}" lev="3" style="" sel="" @click="active = 'tabError'">ERROR</li>
                </ul>
                <pa-logger-container-cell v-model="active">
                    <dl>
                        <pa-logger-cell v-for="n in 8" id="tabAll" v-model="keyword">
                            <dt class="color_info">http://test3-cfs-phone-web.pingan.com.cn/cfsssfront/eloan/forwardWangCaiInfo.do</dt>
                            <dd class="">
                                <p class="log-page-time">8-10-2016 19:39:26</p>
                                <p class="log-page-content">{"flag":"0","msg":"尚未登录,需重新登录！","data":null}</p>
                            </dd>
                        </pa-logger-cell>
                        <pa-logger-cell v-for="n in 6" id="tabDebug">
                            <dt class="color_debug">apply_record - init</dt>
                            <dd class="">
                                <p class="log-page-time">8-1-2016 17:45:35</p>
                                <p class="log-page-content">1470044735702</p>
                            </dd>
                        </pa-logger-cell>
                        <pa-logger-cell v-for="n in 4" id="tabInfo">
                            <dt class="color_info">http://test3-cfs-phone-web.pingan.com.cn/cfsssfront/eloan/forwardWangCaiInfo.do
                            </dt>
                            <dd class="">
                                <p class="log-page-time">8-10-2016 19:39:26</p>
                                <p class="log-page-content">{"flag":"0","msg":"尚未登录,需重新登录！","data":null}</p>
                            </dd>
                        </pa-logger-cell>
                        <pa-logger-cell v-for="n in 3" id="tabWarn"></pa-logger-cell>
                        <pa-logger-cell v-for="n in 1" id="tabError">
                            <dt class="color_error">index_apply - calcLimit</dt>
                            <dd class="">
                                <p class="log-page-time">8-10-2016 17:37:55</p>
                                <p class="log-page-content">试算配置数据解析错误，使用默认值</p>
                            </dd>
                        </pa-logger-cell>
                    </dl>
                </pa-logger-container-cell>
            </div>
        </div>
    </template>

    <script>
        import Vue from 'vue'
        import LoggerContainerCell from './LoggerContainerCell'
        import LoggerCell from './LoggerCell'
        import Search from './Search'

        const componentPrefix = 'pa-'   //  组件前缀

        //   注册组件
        Vue.component(`${componentPrefix}${LoggerContainerCell.name}`, LoggerContainerCell)
        Vue.component(`${componentPrefix}${LoggerCell.name}`, LoggerCell)
        Vue.component(`${componentPrefix}${Search.name}`, Search)
        export default {
            name: 'logger',
            data() {
                return {
                    active: 'tabAll',
                    keyword: ''
                }
            },
            events: {
                setKeyword(keyword) {
                    console.log(keyword)
                }
            }
        }
    </script>

    <style lang="less">
        @import './assets/log_page';
        input, img {
            vertical-align: middle;
        }
    </style>

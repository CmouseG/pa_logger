<template>
    <div v-show="id === $parent.currentActive" @click="reSearch">
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: 'logger-cell',
        data() {
            return {
                keyword: ''
            }
        },
        props: {
            id: '',
            value: {}
        },
        methods: {
            reSearch() {
                let root = this.$parent.$parent
                root.keyword = this.$el.querySelector('dt').innerText
            }
        }
    }
</script>

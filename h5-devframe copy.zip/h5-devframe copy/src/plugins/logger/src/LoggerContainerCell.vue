    <template>
        <div>
            <slot></slot>
        </div>
    </template>

    <script>
        //  import arrayFindIndex from 'array-find-index'
        export default {
            name: 'logger-container-cell',
            data() {
                return {
                    currentActive: this.value
                }
            },
            props: {
                value: {}
            },
            watch: {
                value(val) {
                    this.currentActive = val
                },
                currentActive(val, oldVal) {
 /*                   const lastIndex = arrayFindIndex(
                        this.$children,
                        item => item.id === oldVal
                    )
                    console.log(lastIndex)*/
                    // this.swipeLeaveTransition(lastIndex)
                }
            },
            methods: {
                swipeLeaveTransition(lastIndex = 0) {
                    if (typeof this.index !== 'number') {
                        this.index = this.$children.findIndex(
                            item => item.id === this.currentActive
                        )
                    }
                }
            }
        }
    </script>
<template>
    <div class="search_bar">
        <span class="icon_con"><img src="./assets/kuodajing.png"></span>
        <input type="text" id="keyword" :value.sync="value">
        <span class="clear_input" style="display: block;">x</span>  
    </div>
</template>

<script>
    export default {
        name: 'search',
        props: {
            value: {}
        }
    }
</script>


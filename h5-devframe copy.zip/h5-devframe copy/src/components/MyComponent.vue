    <template>
        <div class="hello">
            <h1>{{ msg }} {{ type }}</h1>
            <slot name="MySlot"></slot>
        </div>
    </template>

    <script>
        let world = 'World'
        export default {
            name: 'my-component',
            props: {
                type: {
                    type: String,
                    required: true,
                    default: '我是'
                }
            },
            data() {
                return {
                    msg: `Hello ${world}!`
                }
            }
        }
    </script>

    <!-- Add "scoped" attribute to limit CSS to this component only -->
    <style scoped>
        h1 {
            color: #42b983;
        }
    </style>
<template>
    <div>
        <x-header>vue demo</x-header>
        <transition name="fade" mode="out-in">
            <router-view></router-view>
        </transition>
    </div>
</template>

<script>
    import XHeader from 'vux-components/x-header'
    export default {
        components: {
            XHeader
        }
    }
</script>

<style lang="less">
@import '~keen-ui/dist/keen-ui.css';
@import './assets/styles/commons/common';
#app {
    margin: 0;

    * {
        font-size: 1.4rem;
    }
}
</style>

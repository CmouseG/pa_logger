import Vue from 'vue'

//   vux-demo
export function getAInput() {
    return Vue.http.get('/static/data/vux-demo.json')
    .then(res => {
        return Promise.resolve(res.data)
    }, res => {
        return Promise.reject(res)
    })
}

<template>
    <div id="a_input" transition="common_page">
        <group>
            <input :value.sync="fromData.name" @input="updateName">
            <x-input :value.sync="fromData.name" title="姓名" is-type="china-name" :show-clear=true placeholder=""></x-input>
            <x-input :value.sync="fromData.id" title="身份证" :show-clear=true placeholder=""></x-input>
            <x-input :value.sync="fromData.mobile" title="手机号码" :show-clear=true placeholder=""></x-input>
        </group>
        <button :value.sync="loading.isShow" @click="changeShow">loading</button>
        <button :value.sync="toast.isShow" @click="testToast">toast</button>
        <button @click="saveAInput(fromData)">save</button>
        <loading :show="loading.isShow" :text="loading.text"></loading>
        <toast type="warn" :show.sync="toast.isShow" :time="3000"></toast>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import Group from 'vux-components/group'
import XInput from 'vux-components/x-input'
import Loading from 'vux-components/loading'
import Toast from 'vux-components/toast'

export default {
    name: 'vux-demo',
    data() {
        return {
            loading: {
                isShow: false,
                text: 'loading...'
            },
            toast: {
                isShow: false
            }
        }
    },
    components: {
        Group,
        XInput,
        Loading,
        Toast
    },
    computed: {
        ...mapGetters({
            fromData: 'getAInputG'
        })
    },
    created() {
        this.$store.dispatch('getAInputA')
    },
    methods: {
        ...mapActions({
            updateName: 'updateName'
        }),
        changeShow() {
            this.loading.isShow = true
            setTimeout(function() {
                this.loading.isShow = false
            }.bind(this), 3000)
        },
        testToast() {
            this.toast.isShow = true
        },
        saveAInput() {}
    }
}
</script>
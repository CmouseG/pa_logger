<template>
    <my-component :type="'你好'">
    <div slot="MySlot"><h1>{{ date | formatDate }}</h1></div>
    </my-component>
</template>
<script>
import MyComponent from '../components/MyComponent'

export default {
    data() {
        return {
            date: Date.now()
        }
    },
    components: {
        MyComponent
    }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1 {
    color: #42b983;
}
</style>

<template>
    <group>
        <cell><router-link to='/hello-world'>hello-world</router-link></cell>
        <cell><router-link to='/vux-demo'>vux-demo(not suport vue@2.0)</router-link></cell>
        <cell><router-link to='/keenui-demo'>keenui-demo(not suport vue@2.0)</router-link></cell>
        <cell><router-link to='/logger'>logger</router-link></cell>
    </group>
</template>

<script>
    import Group from 'vux-components/group'
    import Cell from 'vux-components/cell'

    export default {
        name: 'info-input',
        components: {
            Group,
            Cell
        }
    }
</script>

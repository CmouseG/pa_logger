<template>
    <div id="keen-demo">
        <ui-textbox
            label="姓名" name="name" type="text" placeholder="Enter your name" validation-rules="required"
        ></ui-textbox>
        <ui-textbox
            label="手机号码" name="mobile" type="text" placeholder="Enter your mobile" validation-rules="required|regex:/^1\d{10}/"
        ></ui-textbox>
    </div>
</template>

<script>
import { UiTextbox } from 'keen-ui'

export default {
    data() {
        return {}
    },
    components: {
        UiTextbox
    }
}
</script>

<style lang="less">
#keen-demo {
    padding: .5rem;
} 
</style>
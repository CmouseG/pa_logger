import Vue from 'vue'
import VueResource from 'vue-resource'
import { sync } from 'vuex-router-sync'

import store from './store'
import router from './router'
import App from './App'
import Filter from './filters'

Vue.config.debug = true

Vue.use(VueResource)
sync(store, router)

export default new Vue({
    store,
    router,
    render: h => h(App),
    filter: {
        Filter
    }
}).$mount('#app')
